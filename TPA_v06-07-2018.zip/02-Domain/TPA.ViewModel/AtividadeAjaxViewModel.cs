﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA.ViewModel
{
    /// <summary>
    /// a mesma coisa que AtividadeViewModel, mas para post/get via json nos métodos ajax
    /// </summary>
    public class AtividadeAjaxViewModel : AtividadeViewModel
    {

    }

}
